// popup.js
// Import browser polyfill if needed
if (typeof browser === 'undefined') {
  var browser = chrome;
}

document.addEventListener('DOMContentLoaded', function() {
  // Select Area button
  document.getElementById("selectArea").addEventListener("click", () => {
    console.log("Select Area button clicked");
    browser.tabs.query({ active: true, currentWindow: true })
      .then(tabs => {
        browser.scripting.executeScript({
          target: { tabId: tabs[0].id },
          files: ["content.js"]
        });
      })
      .catch(error => console.error("Failed to execute content script:", error));
  });

  // Search Last Capture button
  document.getElementById("searchLast").addEventListener("click", () => {
    console.log("Search Last Capture button clicked");
    browser.runtime.sendMessage({ action: "searchWithLastImage" });
  });
  
  // Display keyboard shortcuts
  const selectAreaShortcut = document.getElementById("selectAreaShortcut");
  const searchLastShortcut = document.getElementById("searchLastShortcut");
  const activateShortcut = document.getElementById("activateShortcut");
  
  browser.commands.getAll().then((commands) => {
    commands.forEach((command) => {
      if (command.name === "start-selection" && command.shortcut) {
        selectAreaShortcut.textContent = `Shortcut: ${command.shortcut}`;
      }
      if (command.name === "search-last-capture" && command.shortcut) {
        searchLastShortcut.textContent = `Shortcut: ${command.shortcut}`;
      }
      if (command.name === "activate-extension" && command.shortcut) {
        activateShortcut.textContent = `Activate: ${command.shortcut}`;
      }
    });
  });
});
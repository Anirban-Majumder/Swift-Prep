// Import browser polyfill
importScripts('browser-polyfill.min.js');

// Main background script
importScripts('background.js')
// background.js
let lastCapturedImage = null;

// Initialize browser polyfill if needed
if (typeof browser === 'undefined') {
  var browser = chrome;
}

// Listen for commands
browser.commands.onCommand.addListener((command) => {
  console.log(`Command received: ${command}`);
  
  if (command === "start-selection" || command === "activate-extension") {
    console.log("Starting area selection...");
    browser.tabs.query({ active: true, currentWindow: true })
      .then(tabs => {
        browser.scripting.executeScript({
          target: { tabId: tabs[0].id },
          files: ["content.js"]
        });
      })
      .catch(error => console.error("Failed to execute content script:", error));
  }
  
  if (command === "search-last-capture" && lastCapturedImage) {
    console.log("Searching with last captured image...");
    browser.tabs.query({ active: true, currentWindow: true })
      .then(tabs => {
        browser.tabs.sendMessage(tabs[0].id, {
          action: "searchWithImage",
          imageData: lastCapturedImage
        });
      })
      .catch(error => console.error("Failed to send message:", error));
  }
});

// Listen for messages from content script
browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "captureTab") {
    console.log("Capturing tab...");
    browser.tabs.captureVisibleTab()
      .then(dataUrl => {
        console.log("Tab captured successfully");
        lastCapturedImage = dataUrl;
        sendResponse({ screenshotUrl: dataUrl });
      })
      .catch(error => {
        console.error("Capture failed:", error);
        sendResponse({ error: error.message });
      });
    return true; // Keep the messaging channel open for async response
  }
  
  if (request.action === "storeImage") {
    console.log("Storing image data...");
    lastCapturedImage = request.imageData;
    sendResponse({ success: true });
    return false;
  }
  
  if (request.action === "searchWithLastImage") {
    console.log("Searching with last captured image...");
    if (lastCapturedImage) {
      browser.tabs.query({ active: true, currentWindow: true })
        .then(tabs => {
          browser.tabs.sendMessage(tabs[0].id, {
            action: "searchWithImage",
            imageData: lastCapturedImage
          });
        })
        .catch(error => console.error("Failed to send message:", error));
    } else {
      console.log("No image captured yet");
    }
    return false;
  }
});
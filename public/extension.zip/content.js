(async function() {
  let startX, startY, endX, endY;
  let lastCapturedImage = null;
  let activeNotifications = [];
  
  // Initialize browser polyfill if needed
  if (typeof browser === 'undefined') {
    var browser = chrome;
  }
  
  // Create and style selection elements
  function createSelectionElements() {
    console.log("Creating selection elements...");
    
    const selectionBox = document.createElement("div");
    Object.assign(selectionBox.style, {
      position: "absolute",
      border: "2px solid #3498db",
      zIndex: "9999",
      pointerEvents: "none",
      boxShadow: "0 0 0 9999px rgba(0, 0, 0, 0.3)",
      borderRadius: "4px"
    });
    
    const overlay = document.createElement("div");
    Object.assign(overlay.style, {
      position: "fixed",
      top: "0",
      left: "0",
      width: "100%",
      height: "100%",
      backgroundColor: "rgba(0,0,0,0.2)",
      zIndex: "9998",
      cursor: "crosshair"
    });
    
    return { selectionBox, overlay };
  }
  
  // Handle image capture and processing
  async function handleImageCapture() {
    console.log("Capturing selected area...");
    
    try {
      const response = await browser.runtime.sendMessage({ action: "captureTab" });
      if (response.error) {
        console.error("Capture failed:", response.error);
        return;
      }
      
      lastCapturedImage = await processImage(response.screenshotUrl);
      console.log("Image processed successfully");
      
      // Store for later use with Ctrl+8
      browser.runtime.sendMessage({
        action: "storeImage",
        imageData: lastCapturedImage
      });
    } catch (error) {
      console.error("Error during image capture:", error);
    }
  }
  
  // Process captured image
  async function processImage(screenshotUrl) {
    console.log("Processing captured image...");
    
    const img = new Image();
    img.src = screenshotUrl;
    await new Promise(resolve => { img.onload = resolve; });
    
    const canvas = document.createElement("canvas");
    const dpr = window.devicePixelRatio;
    const cropX = Math.min(startX, endX) * dpr;
    const cropY = Math.min(startY, endY) * dpr;
    const cropWidth = Math.abs(startX - endX) * dpr;
    const cropHeight = Math.abs(startY - endY) * dpr;
    
    canvas.width = cropWidth;
    canvas.height = cropHeight;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, cropX, cropY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
    
    return canvas.toDataURL("image/png");
  }
  
  // Initialize area selection
  function initializeSelection() {
    console.log("Initializing area selection...");
    
    const { selectionBox, overlay } = createSelectionElements();
    document.body.appendChild(overlay);
    document.body.appendChild(selectionBox);
    
    let isSelecting = false;
    
    overlay.addEventListener("mousedown", e => {
      isSelecting = true;
      startX = e.clientX;
      startY = e.clientY;
      selectionBox.style.left = startX + "px";
      selectionBox.style.top = startY + "px";
    });
    
    overlay.addEventListener("mousemove", e => {
      if (!isSelecting) return;
      
      endX = e.clientX;
      endY = e.clientY;
      
      const left = Math.min(startX, endX);
      const top = Math.min(startY, endY);
      const width = Math.abs(startX - endX);
      const height = Math.abs(startY - endY);
      
      Object.assign(selectionBox.style, {
        left: left + "px",
        top: top + "px",
        width: width + "px",
        height: height + "px",
        display: "block"
      });
    });
    
    overlay.addEventListener("mouseup", async () => {
      isSelecting = false;
      await handleImageCapture();
      overlay.remove();
      selectionBox.remove();
      
      // Automatically process the captured image
      if (lastCapturedImage) {
        sendCroppedImage(lastCapturedImage);
      }
    });
  }
  
  async function sendCroppedImage(imageDataUrl) {
 
    const API_URL = "https://api.groq.com/openai/v1/chat/completions";
    const API_KEY = "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";
    const headers = {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${API_KEY}`
    };

    const payload = {
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "You are Image to text AI. Please convert this image to text. Do not provide additional information or explanation or context or the answer. Only provide the text extracted from the image."
            },
            {
              type: "image_url",
              image_url: { url: imageDataUrl }
            }
          ]
        }
      ],
      model: "llama-3.2-11b-vision-preview",
      temperature: 1,
      max_completion_tokens: 1024,
      top_p: 1,
      stream: false,
      stop: null
    };

    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: headers,
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        const result = await res.json();
        const extractedText = result.choices[0].message.content;
        console.log("Extracted Text: ", extractedText);
        
        createNotification("Text Extracted", extractedText.substring(0, 50) + "...", "#2ecc71");
        
        // Now send the extracted text to multiple models.
        sendQuestionToModels(extractedText);
      } else {
        console.error("Error: ", res.status, await res.text());
        createNotification("Error", "Failed to extract text from image", "#e74c3c");
      }
    } catch (error) {
      console.error("Exception occurred:", error);
      createNotification("Error", "Failed to process image: " + error.message, "#e74c3c");
    }
  }

  async function sendQuestionToModels(text) {
    const API_URL = "https://api.groq.com/openai/v1/chat/completions";
    const API_KEY = "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";
    const headers = {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${API_KEY}`
    };
    const models = [
      "qwen-2.5-32b",
      "llama-3.3-70b-versatile",
      "mixtral-8x7b-32768",
      "gemma2-9b-it"
    ];

    const payloadTemplate = {
      messages: [
        {
          role: "system",
          content: "You are an AI assistant specialized in answering multiple-choice questions (MCQs) accurately. When provided with a question and answer choices, analyze the question carefully and determine the most correct answer based on logic, knowledge, and reasoning. If the question is ambiguous, choose the best possible answer. Ensure your responses are only the correct answers to the questions. Do not provide additional information or explanation or context or the question itself."
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: text
            }
          ]
        }
      ],
      temperature: 1,
      max_completion_tokens: 1024,
      top_p: 1,
      stream: false,
      stop: null
    };


    // Send to each model and display results as they come in
    models.forEach(async (model) => {
      try {
        const payload = { ...payloadTemplate, model: model };
        
        // Create a loading notification for this specific model
        const modelNotifId = createNotification(model, "Processing...", "#f39c12");
        
        const res = await fetch(API_URL, {
          method: "POST",
          headers: headers,
          body: JSON.stringify(payload)
        });
        
        if (res.ok) {
          const result = await res.json();
          let answer = result.choices[0].message.content;
          if (answer.includes("</think>")) {
            answer = answer.split("</think>")[1].trim();
          }
          
          // Update the notification with the answer
          updateNotification(modelNotifId, model, answer, getModelColor(model));
        } else {
          const errorText = await res.text();
          updateNotification(modelNotifId, model, `Error: ${res.status}`, "#e74c3c");
        }
      } catch (error) {
        createNotification(model, `Error: ${error.message}`, "#e74c3c");
      }
    });
  }

  // Get a color for each model
  function getModelColor(model) {
    const colorMap = {
      "qwen-2.5-32b": "#3498db",        // Blue
      "llama-3.3-70b-versatile": "#9b59b6", // Purple
      "mixtral-8x7b-32768": "#2ecc71",   // Green
      "gemma2-9b-it": "#e67e22"         // Orange
    };
    
    return colorMap[model] || "#34495e"; // Default dark gray
  }

  // Create a notification that displays at the top left
  function createNotification(title, message, color) {
    // Generate a unique ID for this notification
    const notifId = 'notif-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
    
    // Create notification container if it doesn't exist
    let notifContainer = document.getElementById('mcq-ai-notifications');
    if (!notifContainer) {
      notifContainer = document.createElement('div');
      notifContainer.id = 'mcq-ai-notifications';
      Object.assign(notifContainer.style, {
        position: 'fixed',
        top: '20px',
        left: '20px',
        zIndex: '10000',
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
        maxWidth: '300px',
        maxHeight: '80vh',
        overflowY: 'auto'
      });
      document.body.appendChild(notifContainer);
    }
    
    // Create the notification element
    const notif = document.createElement('div');
    notif.id = notifId;
    Object.assign(notif.style, {
      backgroundColor: color || '#34495e',
      color: '#fff',
      padding: '12px 15px',
      borderRadius: '5px',
      boxShadow: '0 2px 10px rgba(0,0,0,0.2)',
      display: 'flex',
      flexDirection: 'column',
      position: 'relative',
      transition: 'all 0.3s ease',
      marginBottom: '10px',
      maxWidth: '100%',
      wordBreak: 'break-word'
    });
    
    // Create title
    const titleElement = document.createElement('div');
    titleElement.textContent = title;
    Object.assign(titleElement.style, {
      fontWeight: 'bold',
      marginBottom: '5px',
      paddingRight: '20px'
    });
    
    // Create message
    const messageElement = document.createElement('div');
    messageElement.textContent = message;
    
    // Create close button
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '×';
    Object.assign(closeBtn.style, {
      position: 'absolute',
      top: '5px',
      right: '5px',
      backgroundColor: 'transparent',
      border: 'none',
      color: '#fff',
      fontSize: '18px',
      cursor: 'pointer',
      padding: '0 5px'
    });
    closeBtn.addEventListener('click', () => {
      removeNotification(notifId);
    });
    
    // Add elements to notification
    notif.appendChild(titleElement);
    notif.appendChild(messageElement);
    notif.appendChild(closeBtn);
    
    // Add to container
    notifContainer.appendChild(notif);
    
    // Set auto-dismiss timer
    setTimeout(() => {
      removeNotification(notifId);
    }, 5000);
    
    // Track active notifications
    activeNotifications.push(notifId);
    
    return notifId;
  }
  
  // Update an existing notification
  function updateNotification(notifId, title, message, color) {
    const notif = document.getElementById(notifId);
    if (!notif) return;
    
    // Update title
    notif.querySelector('div:first-child').textContent = title;
    
    // Update message
    notif.querySelector('div:nth-child(2)').textContent = message;
    
    // Update color if provided
    if (color) {
      notif.style.backgroundColor = color;
    }
    
    // Reset the auto-dismiss timer
    clearTimeout(notif.dismissTimer);
    notif.dismissTimer = setTimeout(() => {
      removeNotification(notifId);
    }, 5000);
  }
  
  // Remove a notification
  function removeNotification(notifId) {
    const notif = document.getElementById(notifId);
    if (!notif) return;
    
    // Add fade-out effect
    notif.style.opacity = '0';
    notif.style.transform = 'translateX(-20px)';
    
    // Remove after animation
    setTimeout(() => {
      notif.remove();
      
      // Remove from active notifications
      const index = activeNotifications.indexOf(notifId);
      if (index > -1) {
        activeNotifications.splice(index, 1);
      }
      
      // Remove container if no more notifications
      if (activeNotifications.length === 0) {
        const container = document.getElementById('mcq-ai-notifications');
        if (container) container.remove();
      }
    }, 300);
  }

  // Listen for messages from background script
  browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "searchWithImage" && request.imageData) {
      console.log("Searching with provided image...");
      sendCroppedImage(request.imageData);
    }
  });
  
  // Initialize the selection process
  initializeSelection();
})();